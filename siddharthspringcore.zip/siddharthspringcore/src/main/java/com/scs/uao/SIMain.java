package com.scs.uao;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.scs.bao.CalculateSI;
import com.scs.dao.SI;

public class SIMain {

	public static void main(String[] args) {
		Resource res = new ClassPathResource("applicationContext.xml");
		BeanFactory bf = new XmlBeanFactory(res);  
		SI s = (SI)bf.getBean("si");
		CalculateSI obj = new CalculateSI();
		float result = obj.calc(s.getP(),s.getR(),s.getT());
		System.out.println("Result is "+result);
	}

}
