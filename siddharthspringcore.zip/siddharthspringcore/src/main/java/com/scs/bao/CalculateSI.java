package com.scs.bao;

public class CalculateSI {
 public float calc(float p,float r,float t)
 {
	 return (p*r*t)/100;
 }
}
